import React from 'react'
import dynamic from 'next/dynamic'

const NotionPage = dynamic(() =>
  import('react-notion-x').then((mod) => mod.NotionRenderer),
  { ssr: false }
)

export default function NotionRenderer({ recordMap }: any) {
  return <NotionPage recordMap={recordMap} fullPage={true} darkMode={false} />
}
